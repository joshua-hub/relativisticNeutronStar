/*******************************************************************************
  PHYS3071 (and PHYS7073) Assignment 5 Baumgardt 0123456
 
  Program as05_neutronstar (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.
 
  About: This C program calculates population changes in two species
         based on the Lotka-Volterra equations and using Euler's mechanism
 
  Compile: gcc -Wall -lm as05_neutronstar.c -o as05_neutronstar
 
  Input: The step size dr in m 
 
  Output: A file massvsradius.dat containing mass and radius for different eps0 
***********************80*character*limit*good*for* a2ps***********************/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#define B      57.0   // Mev/fm^3
#define PI     3.1415927
#define K      1.322E-42
#define EV     1.602E-13  // MeV->kg m^2/sec^2
#define C      2.99E8     // c in m/sec
#define MSUN   1.988E30   // Msun

int main() {
 double eps,eps0,r,mcum,dr,dmdr,dedr;
 double eps05,r05,mcum05;               // Variables at the intermediate point
 double mnew,rnew,mtov,rtov;            // Mass and radius for Newtonian and TOV case 
 int iloop;                             // Loop counter
 FILE *dat;

 printf("Enter Delta r in m:  ");
 scanf("%lf",&dr);

 dr *= 1E15;  // Convert from m to fm

 dat = fopen ("massvsradius.dat","w");

 for (iloop=0;iloop<80;iloop++) {
   eps0 = (4.2+(20.0-4.2)*iloop/80.0)*B;   // Calculate initial eps

   mcum = 0.0;    // Initialize M(r)
   r = dr;        // Set initial r equal to dr
   eps = eps0;    // Initialize eps(r)

   do {
     dedr = -3.0*K*eps*mcum/r/r;
     dmdr = 4.0*PI*r*r*eps;

// Half step 
     eps05  = eps + dedr*dr*0.5;
     mcum05 = mcum + dmdr*dr*0.5;
     r05    = r + dr*0.5;
 
     dedr = -3.0*K*eps05*mcum05/r05/r05;
     dmdr = 4.0*PI*r05*r05*eps05;

// Full step 
     eps  += dedr*dr;
     mcum += dmdr*dr;
     r += dr;
   } while (eps>4.0*B);

   mnew = mcum*EV/C/C/MSUN;   // Total mass in Newtonian case in Msun
   rnew = r/1E18;             // NS radius in Newtonian case in km

// Now the relativistic case
   mcum = 0.0;    // Initialize M(r)
   r = dr;        // Set initial r equal to dr
   eps = eps0;    // Initialize eps(r)

   do {
     dedr =-4.0*K*(eps-B)*(mcum+4.0*PI*r*r*r*(eps-4.0*B)/3.0)/(r*r*(1.0-2.0*K*mcum/r));
     dmdr = 4.0*PI*r*r*eps;

// Half step 
     eps05  = eps + dedr*dr*0.5;
     mcum05 = mcum + dmdr*dr*0.5;
     r05    = r + dr*0.5;
 
     dedr =-4.0*K*(eps05-B)*(mcum05+4.0*PI*r05*r05*r05*(eps05-4.0*B)/3.0)/(r05*r05*(1.0-2.0*K*mcum05/r05));
     dmdr = 4.0*PI*r05*r05*eps05;

// Full step 
     eps  += dedr*dr;
     mcum += dmdr*dr;
     r += dr;
   } while (eps>4.0*B);

   mtov = mcum*EV/C/C/MSUN;   // Total mass in relativistic case in Msun
   rtov = r/1E18;             // NS radius in relativistic case in km

   fprintf(dat,"%10.4lf %10.5lf %10.5lf %10.5lf %10.5lf\n",eps0,rnew,mnew,rtov,mtov);
 } 
 fclose(dat);

 printf("This program finished OK !\n");
 exit(0);
}
